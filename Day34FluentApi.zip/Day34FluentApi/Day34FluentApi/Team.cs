﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34FluentApi
{
    class Team
    {
        public int TeamId { get; set; }
        public string TeamName { get; set; }
        public int Size { get; set; }


        //navigation props
        //a team can have 0 or more employees
        public virtual ICollection<Employee> Employees { get; set; }
    }
}
