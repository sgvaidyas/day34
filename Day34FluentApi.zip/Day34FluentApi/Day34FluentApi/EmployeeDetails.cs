﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34FluentApi
{
    class EmployeeDetails
    {
        public int EmployeeId { get; set; }
        public string bloodgroup { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string zip { get; set; }

        //navigation
        //1 to 1 =>employee detail is associated with 1 emp
        public virtual Employee Employee { get; set; }
    }
}
