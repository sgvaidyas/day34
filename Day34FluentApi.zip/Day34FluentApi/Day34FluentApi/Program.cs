﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day34FluentApi
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MyDbContext db = new MyDbContext();
                Department d = new Department();
                d.Departmentname = "ROBOTICS";
                db.Departments.Add(d);
                db.SaveChanges();
                Console.WriteLine("Database created");
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
