﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;

namespace Day34FluentApi
{
    class MyDbContext:DbContext
    {
        public MyDbContext():base("name=mydb")
        {

        }
        public virtual DbSet<Department> Departments { get; set; }
        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<EmployeeDetails> EmployeeDetails { get; set; }
        public virtual DbSet<Project> Projects { get; set; }
        public virtual DbSet<Team> Teams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            #region Entity Configurations
            //Totable-> Configure/set table name in sql scripts
            modelBuilder.Entity<Department>().ToTable("Dept");

            //haskey will be primary key usually the table department has
            //DeptId instead of DepartmentId hence we need to configure it as Primary Key
            modelBuilder.Entity<Department>().HasKey(d=>d.DeptId);

            //the employee details has the key EmployeeId thats not following domain class rules
            //hence making this as primary key explicitly
            modelBuilder.Entity<EmployeeDetails>().HasKey(ed => ed.EmployeeId);

            #endregion

            #region PropertyConfigurations
            //Property -> Employee id will be disabled wrt Autoincrement
            modelBuilder.Entity<Employee>().Property(e => e.EmployeeId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            //empname will be changed to Ename (renaming column) 
            //isrequired making it not null 
            modelBuilder.Entity<Employee>().Property(e => e.EmpName).HasColumnName("Ename")
                                                                    .IsRequired()
                                                                    .HasColumnType("varchar")
                                                                    .HasMaxLength(50);

            modelBuilder.Entity<Employee>().Property(e => e.phone).IsRequired().HasMaxLength(10);


            #endregion

            #region Association configuration

            //one to one relationship Employee -> Employeedetails
            //     each emp can have(HasOptional) 0/1 empdetails               every empdetail should have 1 employee
            modelBuilder.Entity<Employee>().HasOptional(e => e.EmployeeDetails).WithRequired(ed=>ed.Employee);

            //dept->Employee  1 to many
            //HasMany-> 1 Department has many Employees  HasMany(d => d.Employees)
            //WithRequired(e => e.Department)  Each employee must and should have 1 dept (with required)
            //HasForeignKey(e=>e.DeptId)   Employee table DeptId -> Foreign key
            //below line if you uncomment all records with respect to deptid = 1 from
            //departments and Employee will be deleted automatically when
            //we delete record from Department
            //modelBuilder.Entity<Department>().HasMany(d => d.Employees).WithRequired(e => e.Department).HasForeignKey(e => e.DeptId);

            //wont allow the dept record to be deleted till we delete all the records
            //that has the entries of same dept id in employees
            modelBuilder.Entity<Department>().HasMany(d => d.Employees).WithRequired(e => e.Department).HasForeignKey(e => e.DeptId).WillCascadeOnDelete(false);


            //one to many relationship (1....*)
            //Team and Employee
            //HasMany(t => t.Employees) ===== each team can have many employees
            //WithOptional(e => e.Team) ====== employee may/may not have team
            //HasForeignKey(e => e.TeamId) ===== employee foreign key is teamid
            modelBuilder.Entity<Team>().HasMany(t => t.Employees).WithOptional(e => e.Team).HasForeignKey(e => e.TeamId);


            //(Employee --- Project) Many to many
            //create a table called as "Employee_Proj"
            //it has 2 columns 1-> EmployeeID(Employee table)
            //                 2->ProjectId(Project table)

            modelBuilder.Entity<Employee>().HasMany(e => e.Projects)
                .WithMany(p => p.Employees)
                .Map(ep =>
                {
                    ep.MapLeftKey("EmployeeId");
                    ep.MapRightKey("ProjectId");
                    ep.ToTable("Employee_Proj");
                });                                                   
         

            #endregion






        }

    }
}
