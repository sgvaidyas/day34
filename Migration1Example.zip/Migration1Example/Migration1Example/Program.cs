﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Migration1Example
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                MyContext ob = new MyContext();
                Product p = new Product();
                p.Pname = "Loreal";
                p.price = 100;
                ob.Products.Add(p);
                ob.SaveChanges();
                Console.WriteLine("Db created");

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}