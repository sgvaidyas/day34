﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Migration1Example
{
    class MyContext:DbContext
    {
        public MyContext():base("Migrationsample1")
        {
            //drop the previous details if there is changes in the model defnition
            //Database.SetInitializer<MyContext>(new DropCreateDatabaseIfModelChanges<MyContext>());

            //Database.SetInitializer<MyContext>(new DropCreateDatabaseAlways<MyContext>());


            Database.SetInitializer<MyContext>(new MigrateDatabaseToLatestVersion<MyContext,Migration1Example.Migrations.Configuration>());
        }
        public virtual DbSet<Product> Products { get; set; }

        public virtual DbSet<Category> Categories { get; set; }
    }
}
