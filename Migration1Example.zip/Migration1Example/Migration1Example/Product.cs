﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Migration1Example
{
    class Product
    {
        public int ProductId { get; set; }
        public string Pname { get; set; }
        public int price{ get; set; }
        public int qty{ get; set; }

    }
}
